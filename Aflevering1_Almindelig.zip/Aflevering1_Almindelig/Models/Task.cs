﻿namespace Aflevering1_Almindelig.Models
{
    public class Task
    {
        public int Id { get; set; }
        public string TaskName { get; set; }
        public int Quantity { get; set; }
        public bool IsComplete { get; set; }
    }
}
